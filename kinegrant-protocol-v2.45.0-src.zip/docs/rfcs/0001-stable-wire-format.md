# KGP-RFC-0001: Stable Wire Format

Status: Accepted (final). The community comment window closed with no
blocking objections recorded as of the v1.0.0 release.
Editor: zoahdev
Related: COMPATIBILITY.md, CONFORMANCE.md

## Motivation

KineGrant now has two interoperable implementations (Python reference and
JavaScript verifier) and a third in progress (Go). Before external vendors
build on the protocol, the wire format must stop changing in breaking ways.

## Scope

- freeze `v0.1` and `v0.2` object shapes exactly as published;
- introduce `1.0` as the first stable version for new deployments;
- additive-only changes within a stable version;
- explicit deprecation policy (announce, deprecate, remove across three
  stable releases minimum).

## Proposal

1. The `1.0` wire format is identical to the published `0.2` capability,
   receipt, request, policy, and evidence schemas plus a version bump.
2. New fields MUST be optional and additive; strict validators reject unknown
   fields only when a profile says so.
3. Breaking changes require a new major version and an RFC.
4. `0.1` and `0.2` continue to verify forever, but new features target `1.0`.
   The reference implementation now issues and verifies `1.0` capabilities
   (`CapabilityIssuer.issue_scoped(wire_version="1.0")`) with the frozen
   object shape and a published `capability-1.0` schema.

## Security properties

- No wire change weakens default-deny, replay protection, or receipt chaining.
- Version negotiation stays explicit; downgrade to an older draft requires the
  deployment's explicit policy.

## Compatibility

- `check_compatibility` becomes the normative gate for wire versions.
- Each implementation publishes the versions it supports.

## Receipt 1.0 (additive extension)

Receipts keep the `0.1` shape as the frozen baseline. As an additive
extension, a receipt MAY use payload `version: "1.0"` to carry two optional
fields:

- `obligation_results`: execution status for each capability obligation
  (`satisfied`, `pending`, or `failed`, with an optional `failure_reason`);
- `failure_reason`: a non-empty reason for a `failed`/`aborted` action.

A `1.0` receipt MUST include at least one of these fields; otherwise it is
not a `1.0` receipt. `0.1` and `1.0` receipts chain together and verify in
the reference implementation and the independent JavaScript and Go
verifiers. The published schema is `spec/schemas/receipt-1.0.schema.json`.
Future obligations are added by extending the known-obligation set in all
three implementations behind the same additive policy.

## Open questions

- Whether `0.2` draft-only fields (e.g., `root_capability_id`) stay required
  in `1.0` or become optional.
- Canonical CBOR as an alternative encoding.

## Test plan

- All suites stay green through the v1.0.0 release (Python 292+ tests,
  JavaScript 7 tests, Go tests, three-way 1.0 interop).
- Cross-implementation fixtures generated from `1.0` objects verify in every
  implementation.
