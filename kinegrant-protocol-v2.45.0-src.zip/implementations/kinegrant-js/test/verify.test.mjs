import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash, createPublicKey, generateKeyPairSync, sign } from "node:crypto";
import { canonicalJson } from "../src/jcs.mjs";
import {
  contentId,
  currentPolicyVersion,
  publicKeyFromKid,
  verifyCapability,
  verifyEnvelope,
  verifyPolicyBundle,
  verifyReceiptChain,
} from "../src/verify.mjs";

const DOMAIN = Buffer.from("KINEGRANT-SIGNED-ENVELOPE-V1\u0000", "utf8");

function b64url(data) {
  return data.toString("base64url");
}

function kidOf(publicKey) {
  const der = publicKey.export({ format: "der", type: "spki" });
  const raw = der.subarray(der.length - 32);
  return "kinegrant:key:ed25519:" + b64url(raw);
}

function signEnvelope(privateKey, payload) {
  const kid = kidOf(createPublicKey(privateKey));
  const protectedData = { alg: "EdDSA", kid, payload };
  const data = Buffer.concat([DOMAIN, Buffer.from(canonicalJson(protectedData), "utf8")]);
  const signature = sign(null, data, privateKey);
  return { alg: "EdDSA", kid, payload, signature: b64url(signature) };
}

test("JCS canonicalizes objects and arrays", () => {
  assert.equal(canonicalJson({ b: 1, a: 2 }), '{"a":2,"b":1}');
  assert.equal(canonicalJson([3, 1, 2]), "[3,1,2]");
  assert.equal(canonicalJson({ x: -0 }), '{"x":0}');
  assert.equal(canonicalJson({ x: "a\u2028b" }), '{"x":"a\\u2028b"}');
});

test("envelope round trip and tamper rejection", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const envelope = signEnvelope(privateKey, { hello: "world" });
  assert.deepEqual(verifyEnvelope(envelope), { hello: "world" });
  envelope.payload.hello = "tampered";
  assert.throws(() => verifyEnvelope(envelope));
});

test("public key from kid round trips", () => {
  const { publicKey } = generateKeyPairSync("ed25519");
  const key = publicKeyFromKid(kidOf(publicKey));
  assert.ok(key.type === "public");
});

function buildCapability(privateKey, publicKey, request, { ttlSeconds = 300 } = {}) {
  const now = Date.now();
  const issuedAt = new Date(now).toISOString().replace(/\.\d{3}Z$/, "Z");
  const expiresAt = new Date(now + ttlSeconds * 1000).toISOString().replace(/\.\d{3}Z$/, "Z");
  const body = {
    type: "kinegrant:PhysicalActionCapability",
    version: "0.1",
    issuer: kidOf(publicKey),
    agent: request.agent,
    target: request.target,
    action: request.action,
    purpose: request.purpose,
    request_digest: "sha256:" + createHash("sha256")
      .update(canonicalJson(request)).digest("hex"),
    policy_digest: "sha256:" + "0".repeat(64),
    matched_policy_ids: ["policy-1"],
    obligations: ["emitActionReceipt"],
    issued_at: issuedAt,
    not_before: issuedAt,
    expires_at: expiresAt,
    nonce: "n".repeat(24),
  };
  const unsigned = { ...body };
  body.capability_id = contentId("kinegrant:cap", unsigned);
  return signEnvelope(privateKey, body);
}

function buildScopedCapability(privateKey, publicKey, request, version = "1.0") {
  const now = new Date();
  const issuedAt = now.toISOString().replace(/\.\d{3}Z$/, "Z");
  const expiresAt = new Date(now.getTime() + 300_000).toISOString().replace(/\.\d{3}Z$/, "Z");
  const body = {
    type: "kinegrant:PhysicalActionCapability",
    version,
    issuer: kidOf(publicKey),
    agent: request.agent,
    target: "urn:kinegrant:interop:target:*",
    actions: ["open", "close"],
    purposes: ["delivery"],
    request_digest: "sha256:" + createHash("sha256")
      .update(canonicalJson(request)).digest("hex"),
    policy_digest: "sha256:" + "0".repeat(64),
    matched_policy_ids: ["policy-1"],
    obligations: ["emitActionReceipt"],
    issued_at: issuedAt,
    not_before: issuedAt,
    expires_at: expiresAt,
    nonce: "n".repeat(24),
    parent_capability_id: null,
    constraints: {},
    approval_tier: 0,
    delegation_allowed: false,
    max_delegation_depth: 0,
    delegate_agent: null,
    delegation_depth: 0,
    delegate_allowlist: null,
  };
  const unsigned = { ...body };
  body.capability_id = contentId("kinegrant:cap", unsigned);
  body.root_capability_id = body.capability_id;
  const unsignedWithRoot = { ...body };
  delete unsignedWithRoot.capability_id;
  delete unsignedWithRoot.root_capability_id;
  body.capability_id = contentId("kinegrant:cap", unsignedWithRoot);
  return signEnvelope(privateKey, body);
}

test("capability verification accepts a valid v0.1 capability", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const request = {
    type: "kinegrant:ActionRequest",
    version: "0.1",
    request_id: "req-1",
    agent: "robot-1",
    target: "door-7",
    action: "open",
    purpose: "delivery",
    issued_at: new Date().toISOString(),
    context: {},
  };
  const envelope = buildCapability(privateKey, publicKey, request);
  const payload = verifyCapability(envelope, request, new Set([envelope.kid]));
  assert.equal(payload.capability_id.startsWith("kinegrant:cap:"), true);
});

test("capability verification rejects a tampered request binding", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const request = {
    type: "kinegrant:ActionRequest",
    version: "0.1",
    request_id: "req-2",
    agent: "robot-1",
    target: "door-7",
    action: "open",
    purpose: "delivery",
    issued_at: new Date().toISOString(),
    context: {},
  };
  const envelope = buildCapability(privateKey, publicKey, request);
  const other = { ...request, request_id: "req-other" };
  assert.throws(() => verifyCapability(envelope, other, new Set([envelope.kid])));
});

test("scoped capability verification accepts a v1.0 capability", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const request = {
    type: "kinegrant:ActionRequest",
    version: "0.1",
    request_id: "req-scoped",
    agent: "robot-1",
    target: "urn:kinegrant:interop:target:door-7",
    action: "open",
    purpose: "delivery",
    issued_at: new Date().toISOString(),
    context: {},
  };
  const envelope = buildScopedCapability(privateKey, publicKey, request, "1.0");
  const payload = verifyCapability(envelope, request, new Set([envelope.kid]));
  assert.equal(payload.version, "1.0");
});

test("receipt chain round trip", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const body = {
    type: "kinegrant:PhysicalActionReceipt",
    version: "0.1",
    executor: kidOf(publicKey),
    capability_id: "kinegrant:cap:" + "a".repeat(64),
    request_digest: "sha256:" + "0".repeat(64),
    agent: "robot-1",
    target: "door-7",
    action: "open",
    purpose: "delivery",
    result: "succeeded",
    started_at: new Date().toISOString(),
    finished_at: new Date().toISOString(),
    evidence_hash: null,
    previous_receipt_hash: null,
  };
  const unsigned = { ...body };
  body.receipt_id = contentId("kinegrant:receipt", unsigned);
  const envelope = signEnvelope(privateKey, body);
  assert.equal(verifyReceiptChain([envelope], new Set([envelope.kid])), true);
});

function buildPolicyBundle(privateKey, publicKey, { version = 1, purposes = ["delivery"], policyId = "urn:policy:door", ttlSeconds = 3600 } = {}) {
  const now = Date.now();
  const body = {
    type: "kinegrant:PolicyBundle",
    schema_version: "0.1",
    policy_id: policyId,
    issuer: kidOf(publicKey),
    version,
    previous_version_digest: null,
    issued_at: new Date(now).toISOString(),
    not_before: new Date(now).toISOString(),
    not_after: new Date(now + ttlSeconds * 1000).toISOString(),
    rules: [
      {
        policy_id: policyId,
        issuer: kidOf(publicKey),
        target: "urn:space:door-1",
        effect: "allow",
        actions: ["open"],
        subjects: ["*"],
        purposes,
        constraints: {},
        obligations: [],
        priority: 0,
        source: {},
      },
    ],
  };
  const unsigned = { ...body };
  body.bundle_id = contentId("kinegrant:policy-bundle", unsigned);
  body.policy_digest = "sha256:" + createHash("sha256")
    .update(canonicalJson({ rules: body.rules }))
    .digest("hex");
  return signEnvelope(privateKey, body);
}

test("policy bundle verify round trip and tamper rejection", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const bundle = buildPolicyBundle(privateKey, publicKey);
  const payload = verifyPolicyBundle(
    bundle,
    new Set([bundle.kid]),
    { expectedPolicyId: "urn:policy:door" },
  );
  assert.equal(payload.version, 1);
  bundle.payload.rules[0].effect = "deny";
  assert.throws(() => verifyPolicyBundle(bundle, new Set([bundle.kid])));
});

test("policy bundle rejects wrong authority and wrong policy", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const { publicKey: otherPublicKey } = generateKeyPairSync("ed25519");
  const bundle = buildPolicyBundle(privateKey, publicKey);
  assert.throws(() => verifyPolicyBundle(bundle, new Set([kidOf(otherPublicKey)])));
  assert.throws(() =>
    verifyPolicyBundle(bundle, new Set([bundle.kid]), { expectedPolicyId: "urn:policy:other" })
  );
});

test("policy bundle expires and future bundles are rejected", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const expired = buildPolicyBundle(privateKey, publicKey, { ttlSeconds: -1 });
  assert.throws(() => verifyPolicyBundle(expired, new Set([expired.kid])));
  const future = buildPolicyBundle(privateKey, publicKey);
  assert.throws(() =>
    verifyPolicyBundle(future, new Set([future.kid]), {
      now: Date.parse(future.payload.not_before) - 1000,
    })
  );
});

test("current policy version picks latest and honors revocation", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const v1 = buildPolicyBundle(privateKey, publicKey, { version: 1 });
  const v2 = buildPolicyBundle(privateKey, publicKey, {
    version: 2,
    purposes: ["delivery", "maintenance"],
  });
  const bundles = [v1.payload, v2.payload];
  assert.equal(currentPolicyVersion(bundles).version, 2);
  assert.equal(
    currentPolicyVersion(bundles, { revoked: ["urn:policy:door:2"] }).version,
    1
  );
  assert.equal(
    currentPolicyVersion(bundles, { revoked: ["urn:policy:door:1", "urn:policy:door:2"] }),
    null
  );
});
